"""Network implementation
"""

import numpy as np
from numpy.typing import NDArray
from ANN.layers import Layer
from ANN.layers.initializers import gorlot
from ANN.optimizers import Optimizer
from ANN.models import Model

class Sequential(Model):
    """Implementation of a neural network object
    """

    def __init__(self, layers : list[Layer], optimizer : Optimizer):

        def forward(inputs):
            """Computes forward pass on the network"""
            output=self.layers[0].forward(inputs)
            for i in range(1, len(self.layers)):
                output=self.layers[i].forward(output)
            return output

        def backward(
                inputs: NDArray[np.float32],
                targets: NDArray[np.float32]
            ):
            """Computes backward pass on the network"""

            self.optimizer.backward(
                self,
                inputs,
                targets
            )

        Model.__init__(
            self,
            forward,
            backward,
            layers,
            optimizer
        )

    def add_layer(self, layer):
        """Add layer to network

        Args:
            layer (Layer): A layer object
        """
        self.layers.append(layer)

