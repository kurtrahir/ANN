"""Neural Network layer object"""


class Layer:
    """Neural Network Layer Object"""


    def __init__(self, forward, get_gradients):
        self.forward = forward
        self.get_gradients = get_gradients
