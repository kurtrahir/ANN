"""Neural Network layer object"""


class Layer:
    """Neural Network Layer Object"""


    def __init__(self, forward, backward):
        self.forward = forward
        self.backward = backward
