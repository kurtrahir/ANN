"""Stochastic Gradient Descent optimizer"""
import numpy as np
from numpy.typing import NDArray
from ANN.optimizers import Optimizer
from ANN.models import Model

class SGD(Optimizer):
    """Stochastic Gradient Descent Optimizer
    """
    def __init__(self, learning_rate):

        self.learning_rate = learning_rate

        def backward(
            model : Model,
            inputs : NDArray[np.float32],
            targets : NDArray[np.float32]
        ):

            n_samples = inputs.shape[0]
            n_inputs = inputs.shape[1]
            gradients = [
                    np.zeros(layer.weights.shape) for layer in model.layers
                ]

            for i in range(n_samples):
                outputs = model.layers[0].forward(inputs[i].reshape(-1,n_inputs))
                for i in range(1, len(model.layers)):
                    outputs = model.layers[i].forward(outputs)

                gradients[-1] += model.layers[-1].get_gradients(targets)

                for i in range(2,len(model.layers)):
                    gradients[-i] += model.layers[-i].get_gradients(
                        gradients[-i+1]
                    )

            for i,layer in enumerate(model.layers):
                layer.weights -= self.learning_rate * gradients[i] / n_samples

        Optimizer.__init__(
            self,
            backward=backward
        )
